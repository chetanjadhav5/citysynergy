# Email Configuration for Inventory Management System

## Current Setup

The inventory management system uses Nodemailer to send email notifications for various inventory-related events:

1. When an item is marked as shareable
2. When an item is requested by another department
3. When a request is approved or rejected
4. When an item is returned to its original department

## Configuration

Email is configured through environment variables in the `.env` file:

```
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=thecitysynergy@gmail.com
SMTP_PASS=jvnp abue uoht kwkf
```

## Troubleshooting Email Issues

If you're not receiving email notifications, check the following:

### 1. SMTP Configuration

Ensure all SMTP configuration variables are correctly set in the `.env` file. The server logs should show:
- "Initializing email service with SMTP configuration" at startup
- "SMTP server is ready to take messages" if the connection is successful

### 2. Resource Manager Role

Emails are only sent to users with the `ROLE_RESOURCE_MANAGER` role. Make sure:
- The user role tables exist for each department
- Users are properly assigned to the Resource Manager role
- The correct `roleId` column name is used in SQL queries

### 3. Debug Logs

When an email sending attempt occurs, look for these log messages:
- "Attempting to send email to [email]"
- "SMTP Config: Host=..., Port=..., Secure=..."
- "Mail options prepared. Sending from [email] to [email]"
- "Email sent successfully: [messageID]"

If there are errors, look for:
- "Error sending email:" followed by detailed error information
- "Failed to send email to [email]:" with specific error details

### 4. Gmail Specific Issues

If using Gmail:
- Ensure "Less secure app access" is enabled for the account
- Check if 2-factor authentication requires an app-specific password
- Verify there are no Gmail sending limits being hit

### 5. Testing Email Functionality

You can test the email functionality by:
1. Running the cross-department testing script which triggers all notification flows
2. Checking server logs for successful email delivery logs
3. Looking for any error messages in the console

## Possible Solutions for Email Issues

1. Update SMTP credentials if they've expired
2. Verify network connectivity to the SMTP server
3. Check for firewall or security settings blocking outgoing SMTP connections
4. Try using a different email provider for testing
5. Update to use OAuth2 instead of password authentication for Gmail 