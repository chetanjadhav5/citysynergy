// Script to check inventory table structure
const { initializeDatabase } = require('./config/database');

async function checkTable() {
    try {
        console.log('Initializing database connection...');
        const sequelize = await initializeDatabase();
        
        console.log('\nChecking common_inventory table structure:');
        const [results] = await sequelize.query('DESCRIBE common_inventory');
        
        console.log('\nTable Structure:');
        results.forEach(field => {
            console.log(`${field.Field}: ${field.Type} ${field.Null === 'YES' ? 'NULL' : 'NOT NULL'} ${field.Default ? `DEFAULT ${field.Default}` : ''}`);
        });
        
        // Check if the specific fields we need exist
        const borrowedFields = results.filter(field => 
            ['isBorrowed', 'borrowedFromDeptId', 'borrowedQuantity'].includes(field.Field)
        );
        
        console.log('\nBorrowing-related fields:');
        if (borrowedFields.length === 3) {
            console.log('✅ All borrowing fields are present in the table');
            borrowedFields.forEach(field => {
                console.log(`- ${field.Field}: ${field.Type} ${field.Null === 'YES' ? 'NULL' : 'NOT NULL'} ${field.Default ? `DEFAULT ${field.Default}` : ''}`);
            });
        } else {
            console.log('❌ Some borrowing fields are missing:');
            const existingFields = borrowedFields.map(f => f.Field);
            ['isBorrowed', 'borrowedFromDeptId', 'borrowedQuantity'].forEach(field => {
                if (existingFields.includes(field)) {
                    const f = borrowedFields.find(bf => bf.Field === field);
                    console.log(`✅ ${field}: ${f.Type} ${f.Null === 'YES' ? 'NULL' : 'NOT NULL'} ${f.Default ? `DEFAULT ${f.Default}` : ''}`);
                } else {
                    console.log(`❌ ${field} is missing`);
                }
            });
        }
        
        process.exit(0);
    } catch (error) {
        console.error('Error:', error);
        process.exit(1);
    }
}

checkTable(); 