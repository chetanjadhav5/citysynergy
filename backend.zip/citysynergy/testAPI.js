// Script to test the inventory API endpoints
const fetch = require('node-fetch');

// Configuration
const BASE_URL = 'http://localhost:3000/api';
const AUTH = {
    email: 'piyush.miraaz@gmail.com',
    password: 'piyush.miraaz'
};

// Store created items and requests for later use
let token = '';
let createdItemId = '';
let createdRequestId = '';

// Helper function for API calls
async function callAPI(endpoint, method = 'GET', body = null, requiresAuth = true) {
    const headers = {
        'Content-Type': 'application/json'
    };
    
    if (requiresAuth && token) {
        headers['Authorization'] = `Bearer ${token}`;
    }
    
    const options = {
        method,
        headers
    };
    
    if (body && (method === 'POST' || method === 'PUT')) {
        options.body = JSON.stringify(body);
    }
    
    try {
        const response = await fetch(`${BASE_URL}${endpoint}`, options);
        const data = await response.json();
        return { status: response.status, data };
    } catch (error) {
        console.error(`Error calling ${endpoint}:`, error);
        return { status: 500, error: error.message };
    }
}

// Main testing function
async function runTests() {
    console.log('Starting API Tests...\n');
    
    // Step 1: Login to get token
    console.log('Step 1: Login');
    const loginResponse = await callAPI('/auth/login', 'POST', AUTH, false);
    if (loginResponse.status !== 200 || !loginResponse.data.token) {
        console.error('Login failed:', loginResponse);
        return;
    }
    token = loginResponse.data.token;
    console.log('✅ Login successful, token obtained');
    console.log('User Info:', loginResponse.data.user);
    console.log('-------------------------------------------\n');
    
    // Step 2: Create a resource
    console.log('Step 2: Create Resource');
    const newResource = {
        itemName: 'Test Laptop',
        itemCategory: 'Electronics',
        itemDescription: 'Test laptop for API testing',
        totalItems: 10,
        isSharable: true
    };
    const createResponse = await callAPI('/inventory', 'POST', newResource);
    if (createResponse.status !== 201 || !createResponse.data.success) {
        console.error('Resource creation failed:', createResponse);
        return;
    }
    createdItemId = createResponse.data.data.itemId;
    console.log('✅ Resource created successfully');
    console.log('Created Item:', createResponse.data.data);
    console.log('-------------------------------------------\n');
    
    // Step 3: List department resources
    console.log('Step 3: List Department Resources');
    const listResponse = await callAPI('/inventory');
    if (listResponse.status !== 200 || !listResponse.data.success) {
        console.error('Listing resources failed:', listResponse);
        return;
    }
    console.log('✅ Resources listed successfully');
    console.log(`Found ${listResponse.data.data.length} resources`);
    console.log('-------------------------------------------\n');
    
    // Step 4: Get inventory history
    console.log('Step 4: Get Inventory History');
    const historyResponse = await callAPI('/inventory/history');
    if (historyResponse.status !== 200 || !historyResponse.data.success) {
        console.error('Getting history failed:', historyResponse);
        return;
    }
    console.log('✅ History retrieved successfully');
    console.log(`Found ${historyResponse.data.data.length} history records`);
    console.log('-------------------------------------------\n');
    
    // Step 5: Mark item as sharable
    console.log('Step 5: Mark Item as Sharable');
    const shareBody = {
        quantity: 5
    };
    const shareResponse = await callAPI(`/inventory/${createdItemId}/share`, 'POST', shareBody);
    if (shareResponse.status !== 200 || !shareResponse.data.success) {
        console.error('Marking as sharable failed:', shareResponse);
        return;
    }
    console.log('✅ Item marked as sharable successfully');
    console.log('Updated Item:', shareResponse.data.data);
    console.log('-------------------------------------------\n');
    
    // Step 6: Get sharable resources
    console.log('Step 6: Get Sharable Resources');
    const sharableResponse = await callAPI('/inventory/sharing');
    if (sharableResponse.status !== 200 || !sharableResponse.data.success) {
        console.error('Getting sharable resources failed:', sharableResponse);
        return;
    }
    console.log('✅ Sharable resources retrieved successfully');
    console.log(`Found ${sharableResponse.data.data.length} sharable resources`);
    console.log('-------------------------------------------\n');
    
    // Step 7: Create resource request (will need a different department's item)
    console.log('Step 7: Create Resource Request');
    console.log('⚠️ Skipping this step as it requires an item from another department');
    console.log('To test, you would need:');
    console.log(`
    POST /api/inventory/request
    {
        "itemId": "ITEM_ID_FROM_ANOTHER_DEPT",
        "fromDept": "ANOTHER_DEPT_ID",
        "quantity": 2
    }
    `);
    console.log('-------------------------------------------\n');
    
    // Step 8: Get resource requests
    console.log('Step 8: Get Resource Requests');
    const requestsResponse = await callAPI('/inventory/requests');
    if (requestsResponse.status !== 200 || !requestsResponse.data.success) {
        console.error('Getting requests failed:', requestsResponse);
        return;
    }
    console.log('✅ Requests retrieved successfully');
    console.log(`Found ${requestsResponse.data.data.length} requests`);
    if (requestsResponse.data.data.length > 0) {
        createdRequestId = requestsResponse.data.data[0].requestId;
    }
    console.log('-------------------------------------------\n');
    
    // Step 9: Update request status (if we have a request)
    if (createdRequestId) {
        console.log('Step 9: Update Request Status');
        const updateStatusBody = {
            status: 'approved'
        };
        const updateStatusResponse = await callAPI(`/inventory/request/${createdRequestId}/status`, 'PUT', updateStatusBody);
        if (updateStatusResponse.status !== 200 || !updateStatusResponse.data.success) {
            console.error('Updating request status failed:', updateStatusResponse);
            return;
        }
        console.log('✅ Request status updated successfully');
        console.log('Updated Request:', updateStatusResponse.data.data);
    } else {
        console.log('Step 9: Update Request Status');
        console.log('⚠️ Skipping this step as no request was found');
    }
    console.log('-------------------------------------------\n');
    
    // Step 10: Get borrowed items
    console.log('Step 10: Get Borrowed Items');
    const borrowedResponse = await callAPI('/inventory/borrowed');
    if (borrowedResponse.status !== 200 || !borrowedResponse.data.success) {
        console.error('Getting borrowed items failed:', borrowedResponse);
        return;
    }
    console.log('✅ Borrowed items retrieved successfully');
    console.log(`Found ${borrowedResponse.data.data.length} borrowed items`);
    console.log('-------------------------------------------\n');
    
    // Step 11: Get lent items
    console.log('Step 11: Get Lent Items');
    const lentResponse = await callAPI('/inventory/lent');
    if (lentResponse.status !== 200 || !lentResponse.data.success) {
        console.error('Getting lent items failed:', lentResponse);
        return;
    }
    console.log('✅ Lent items retrieved successfully');
    console.log(`Found ${lentResponse.data.data.length} lent items`);
    console.log('-------------------------------------------\n');
    
    // Step 12: Return borrowed items (if we have any)
    console.log('Step 12: Return Borrowed Items');
    console.log('⚠️ Skipping this step as it requires a borrowed item');
    console.log('To test, you would need:');
    console.log(`
    POST /api/inventory/return
    {
        "itemId": "BORROWED_ITEM_ID",
        "toDept": "ORIGINAL_DEPT_ID",
        "quantity": 2
    }
    `);
    console.log('-------------------------------------------\n');
    
    // Step 13: Search inventory
    console.log('Step 13: Search Inventory');
    const searchResponse = await callAPI('/inventory/search?query=laptop&isSharable=true');
    if (searchResponse.status !== 200 || !searchResponse.data.success) {
        console.error('Searching inventory failed:', searchResponse);
        return;
    }
    console.log('✅ Search completed successfully');
    console.log(`Found ${searchResponse.data.data.length} matching items`);
    console.log('-------------------------------------------\n');
    
    console.log('🎉 All tests completed!');
}

// Run the tests
runTests().catch(error => {
    console.error('Test failed with error:', error);
}); 