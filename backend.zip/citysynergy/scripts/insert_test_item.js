const mysql = require('mysql2/promise');
require('dotenv').config();

async function insertTestItem() {
    try {
        console.log('Connecting to database...');
        const connection = await mysql.createConnection({
            host: process.env.DB_HOST,
            user: process.env.DB_USER,
            password: process.env.DB_PASSWORD,
            database: process.env.DB_NAME
        });

        // Get current timestamp for createdAt and updatedAt
        const now = new Date().toISOString().slice(0, 19).replace('T', ' ');
        
        // Insert test item
        console.log('Inserting test item...');
        const [result] = await connection.query(`
            INSERT INTO common_inventory (
                itemId, 
                deptId, 
                itemName, 
                itemCategory, 
                itemDescription, 
                totalItems, 
                availableItems, 
                isSharable, 
                lastUpdatedBy, 
                isDeleted, 
                createdAt, 
                updatedAt, 
                isBorrowed, 
                borrowedFromDeptId, 
                borrowedQuantity, 
                sharedItems
            ) VALUES (
                CONCAT('ITM', LPAD(FLOOR(RAND() * 10000), 3, '0')), 
                'DEPT001', 
                'Test Laptop', 
                'Electronics', 
                'Test laptop for testing purposes', 
                10, 
                10, 
                1, 
                'USR004', 
                0, 
                '${now}', 
                '${now}', 
                0, 
                NULL, 
                0, 
                0
            )
        `);

        console.log('Item inserted successfully!');
        console.log('Insert result:', result);

        // Close the connection
        await connection.end();
        console.log('Database connection closed.');
    } catch (error) {
        console.error('Error inserting test item:', error);
    }
}

// Run the function
insertTestItem(); 