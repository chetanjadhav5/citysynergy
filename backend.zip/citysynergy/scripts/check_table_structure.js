const mysql = require('mysql2/promise');
require('dotenv').config();

async function checkTableStructure() {
    try {
        console.log('Connecting to database...');
        const connection = await mysql.createConnection({
            host: process.env.DB_HOST,
            user: process.env.DB_USER,
            password: process.env.DB_PASSWORD,
            database: process.env.DB_NAME
        });

        console.log('Getting common_inventory table structure...');
        const [columns] = await connection.query(`
            SHOW COLUMNS FROM common_inventory
        `);

        console.log('common_inventory table structure:');
        columns.forEach(column => {
            console.log(`${column.Field}: ${column.Type} ${column.Null === 'YES' ? 'NULL' : 'NOT NULL'} ${column.Default ? `DEFAULT ${column.Default}` : ''}`);
        });

        // Close the connection
        await connection.end();
        console.log('Database connection closed.');
    } catch (error) {
        console.error('Error checking table structure:', error);
    }
}

// Run the function
checkTableStructure(); 