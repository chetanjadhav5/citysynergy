const mysql = require('mysql2/promise');
require('dotenv').config();

async function checkHistoryTable() {
    try {
        console.log('Connecting to database...');
        const connection = await mysql.createConnection({
            host: process.env.DB_HOST,
            user: process.env.DB_USER,
            password: process.env.DB_PASSWORD,
            database: process.env.DB_NAME
        });

        // Check table structure
        console.log('Getting inventory_history table structure...');
        try {
            const [columns] = await connection.query(`
                SHOW COLUMNS FROM inventory_history
            `);
            
            console.log('inventory_history table structure:');
            columns.forEach(column => {
                console.log(`${column.Field}: ${column.Type} ${column.Null === 'YES' ? 'NULL' : 'NOT NULL'} ${column.Default ? `DEFAULT ${column.Default}` : ''}`);
            });
            
            // Check if isDeleted column exists
            const hasIsDeleted = columns.some(column => column.Field === 'isDeleted');
            
            if (!hasIsDeleted) {
                console.log('\nisDeleted column does not exist. Adding it now...');
                await connection.query(`
                    ALTER TABLE inventory_history 
                    ADD COLUMN isDeleted BOOLEAN NOT NULL DEFAULT false
                `);
                console.log('isDeleted column added successfully!');
            } else {
                console.log('\nisDeleted column already exists.');
            }
        } catch (error) {
            if (error.code === 'ER_NO_SUCH_TABLE') {
                console.log('inventory_history table does not exist. Creating it...');
                await connection.query(`
                    CREATE TABLE inventory_history (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        itemId VARCHAR(255) NOT NULL,
                        action VARCHAR(50) NOT NULL,
                        previousValue JSON,
                        newValue JSON NOT NULL,
                        performedBy VARCHAR(255) NOT NULL,
                        isDeleted BOOLEAN NOT NULL DEFAULT false,
                        createdAt DATETIME NOT NULL,
                        updatedAt DATETIME NOT NULL,
                        FOREIGN KEY (itemId) REFERENCES common_inventory(itemId),
                        FOREIGN KEY (performedBy) REFERENCES common_users(uuid)
                    )
                `);
                console.log('inventory_history table created successfully!');
            } else {
                throw error;
            }
        }

        // Close the connection
        await connection.end();
        console.log('Database connection closed.');
    } catch (error) {
        console.error('Error checking inventory_history table:', error);
    }
}

// Run the function
checkHistoryTable(); 