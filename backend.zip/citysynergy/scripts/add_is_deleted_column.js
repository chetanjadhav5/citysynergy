const { initializeDatabase } = require('../config/database');
const mysql = require('mysql2/promise');
require('dotenv').config();

async function addIsDeletedColumn() {
    try {
        console.log('Connecting to database...');
        const connection = await mysql.createConnection({
            host: process.env.DB_HOST,
            user: process.env.DB_USER,
            password: process.env.DB_PASSWORD,
            database: process.env.DB_NAME
        });

        console.log('Checking if isDeleted column exists in common_inventory table...');
        const [columns] = await connection.query(`
            SELECT COLUMN_NAME 
            FROM INFORMATION_SCHEMA.COLUMNS 
            WHERE TABLE_SCHEMA = '${process.env.DB_NAME}' 
            AND TABLE_NAME = 'common_inventory' 
            AND COLUMN_NAME = 'isDeleted'
        `);

        if (columns.length === 0) {
            console.log('isDeleted column does not exist. Adding it now...');
            
            await connection.query(`
                ALTER TABLE common_inventory 
                ADD COLUMN isDeleted BOOLEAN NOT NULL DEFAULT false
            `);
            
            console.log('isDeleted column added successfully!');
        } else {
            console.log('isDeleted column already exists in common_inventory table.');
        }

        // Close the connection
        await connection.end();
        console.log('Database connection closed.');
        console.log('Database update completed successfully.');

    } catch (error) {
        console.error('Error updating database:', error);
    }
}

// Run the function
addIsDeletedColumn(); 