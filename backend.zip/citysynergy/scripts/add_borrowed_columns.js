const mysql = require('mysql2/promise');
require('dotenv').config();

async function addBorrowedColumns() {
    try {
        console.log('Connecting to database...');
        const connection = await mysql.createConnection({
            host: process.env.DB_HOST,
            user: process.env.DB_USER,
            password: process.env.DB_PASSWORD,
            database: process.env.DB_NAME
        });

        // Check for borrowedFromDeptId column
        console.log('Checking if borrowedFromDeptId column exists...');
        let [columns] = await connection.query(`
            SELECT COLUMN_NAME 
            FROM INFORMATION_SCHEMA.COLUMNS 
            WHERE TABLE_SCHEMA = '${process.env.DB_NAME}' 
            AND TABLE_NAME = 'common_inventory' 
            AND COLUMN_NAME = 'borrowedFromDeptId'
        `);

        if (columns.length === 0) {
            console.log('borrowedFromDeptId column does not exist. Adding it now...');
            await connection.query(`
                ALTER TABLE common_inventory 
                ADD COLUMN borrowedFromDeptId VARCHAR(255) NULL
            `);
            console.log('borrowedFromDeptId column added successfully!');
        } else {
            console.log('borrowedFromDeptId column already exists.');
        }

        // Check for borrowedQuantity column
        console.log('\nChecking if borrowedQuantity column exists...');
        [columns] = await connection.query(`
            SELECT COLUMN_NAME 
            FROM INFORMATION_SCHEMA.COLUMNS 
            WHERE TABLE_SCHEMA = '${process.env.DB_NAME}' 
            AND TABLE_NAME = 'common_inventory' 
            AND COLUMN_NAME = 'borrowedQuantity'
        `);

        if (columns.length === 0) {
            console.log('borrowedQuantity column does not exist. Adding it now...');
            await connection.query(`
                ALTER TABLE common_inventory 
                ADD COLUMN borrowedQuantity INT NOT NULL DEFAULT 0
            `);
            console.log('borrowedQuantity column added successfully!');
        } else {
            console.log('borrowedQuantity column already exists.');
        }

        // Close the connection
        await connection.end();
        console.log('Database connection closed.');
        console.log('Database update completed successfully.');
    } catch (error) {
        console.error('Error updating database:', error);
    }
}

// Run the function
addBorrowedColumns(); 