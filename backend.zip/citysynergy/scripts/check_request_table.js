const mysql = require('mysql2/promise');
require('dotenv').config();

async function checkRequestTable() {
    try {
        console.log('Connecting to database...');
        const connection = await mysql.createConnection({
            host: process.env.DB_HOST,
            user: process.env.DB_USER,
            password: process.env.DB_PASSWORD,
            database: process.env.DB_NAME
        });

        // Check table structure
        console.log('Getting inventory_request table structure...');
        try {
            const [columns] = await connection.query(`
                SHOW COLUMNS FROM inventory_request
            `);
            
            console.log('inventory_request table structure:');
            columns.forEach(column => {
                console.log(`${column.Field}: ${column.Type} ${column.Null === 'YES' ? 'NULL' : 'NOT NULL'} ${column.Default ? `DEFAULT ${column.Default}` : ''}`);
            });
            
            // Check for missing columns
            const columnsToCheck = [
                { name: 'quantity', type: 'INT NOT NULL DEFAULT 1' },
                { name: 'isDeleted', type: 'BOOLEAN NOT NULL DEFAULT false' }
            ];
            
            for (const column of columnsToCheck) {
                const hasColumn = columns.some(c => c.Field === column.name);
                
                if (!hasColumn) {
                    console.log(`\n${column.name} column does not exist. Adding it now...`);
                    await connection.query(`
                        ALTER TABLE inventory_request 
                        ADD COLUMN ${column.name} ${column.type}
                    `);
                    console.log(`${column.name} column added successfully!`);
                } else {
                    console.log(`\n${column.name} column already exists.`);
                }
            }
        } catch (error) {
            if (error.code === 'ER_NO_SUCH_TABLE') {
                console.log('inventory_request table does not exist. Creating it...');
                await connection.query(`
                    CREATE TABLE inventory_request (
                        requestId VARCHAR(255) PRIMARY KEY,
                        itemId VARCHAR(255) NOT NULL,
                        fromDept VARCHAR(255) NOT NULL,
                        forDept VARCHAR(255) NOT NULL,
                        quantity INT NOT NULL DEFAULT 1,
                        requestStatus ENUM('pending', 'approved', 'rejected') NOT NULL DEFAULT 'pending',
                        isDeleted BOOLEAN NOT NULL DEFAULT false,
                        createdAt DATETIME NOT NULL,
                        updatedAt DATETIME NOT NULL,
                        FOREIGN KEY (itemId) REFERENCES common_inventory(itemId),
                        FOREIGN KEY (fromDept) REFERENCES common_dept(deptId),
                        FOREIGN KEY (forDept) REFERENCES common_dept(deptId)
                    )
                `);
                console.log('inventory_request table created successfully!');
            } else {
                throw error;
            }
        }

        // Close the connection
        await connection.end();
        console.log('Database connection closed.');
    } catch (error) {
        console.error('Error checking inventory_request table:', error);
    }
}

// Run the function
checkRequestTable(); 