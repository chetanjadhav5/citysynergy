// Database initialization utilities
