// Cross-department functionality testing for the inventory management system
import fetch from 'node-fetch';

// Configuration
const BASE_URL = 'http://localhost:3000/api';
const DEPT1_USER = {
    email: 'piyush.miraaz@gmail.com',
    password: 'piyush.miraaz'
};

const DEPT2_USER = {
    email: 'thecitysynergy@gmail.com',
    password: 'city@2025'
};

// Store tokens and info for both departments
let dept1 = {
    token: '',
    deptId: '',
    deptName: '',
    user: null
};

let dept2 = {
    token: '',
    deptId: '',
    deptName: '',
    user: null
};

let createdItemId = '';
let requestId = '';

// Helper function for API calls
async function callAPI(endpoint, method = 'GET', body = null, auth = null) {
    const headers = {
        'Content-Type': 'application/json'
    };
    
    if (auth) {
        headers['Authorization'] = `Bearer ${auth}`;
    }
    
    const options = {
        method,
        headers
    };
    
    if (body && (method === 'POST' || method === 'PUT')) {
        options.body = JSON.stringify(body);
    }
    
    try {
        const response = await fetch(`${BASE_URL}${endpoint}`, options);
        const data = await response.json();
        return { status: response.status, data, success: true };
    } catch (error) {
        console.error(`Error calling ${endpoint}:`, error);
        return { status: 500, error: error.message, success: false };
    }
}

// Main testing function
async function runTests() {
    console.log('\n=== CROSS-DEPARTMENT FUNCTIONALITY TESTING ===\n');
    
    // STEP 1: Login as both department users
    console.log('\n--- Step 1: Login to Both Departments ---');
    
    // Login as Department 1 User
    const login1Response = await callAPI('/auth/login', 'POST', DEPT1_USER, null);
    
    if (!login1Response.success || !login1Response.data.data.accessToken) {
        console.log('Department 1 login failed. Cannot proceed with tests.');
        console.log(login1Response);
        return;
    }
    
    dept1.token = login1Response.data.data.accessToken;
    dept1.user = login1Response.data.data.user;
    dept1.deptId = dept1.user.deptId;
    dept1.deptName = dept1.user.deptName || 'Department 1';
    
    console.log(`✓ Logged in as Dept 1: ${dept1.user.name} (Dept: ${dept1.deptId})`);
    
    // Login as Department 2 User
    const login2Response = await callAPI('/auth/login', 'POST', DEPT2_USER, null);
    
    if (!login2Response.success || !login2Response.data.data.accessToken) {
        console.log('Department 2 login failed. Cannot proceed with full cross-department test.');
        console.log(login2Response);
        return;
    }
    
    dept2.token = login2Response.data.data.accessToken;
    dept2.user = login2Response.data.data.user;
    dept2.deptId = dept2.user.deptId;
    dept2.deptName = dept2.user.deptName || 'Department 2';
    
    console.log(`✓ Logged in as Dept 2: ${dept2.user.name} (Dept: ${dept2.deptId})`);
    
    // STEP 2: Create a shareable item in Department 1
    console.log('\n--- Step 2: Create a Shareable Item in Department 1 ---');
    
    const itemToCreate = {
        itemName: 'Cross-Dept Test Laptop',
        itemCategory: 'Electronics',
        itemDescription: 'Laptop for cross-department sharing test',
        totalItems: 5,
        isSharable: true
    };
    
    const createResponse = await callAPI('/inventory', 'POST', itemToCreate, dept1.token);
    
    if (!createResponse.success || !createResponse.data.success) {
        console.log('Failed to create shareable item. Cannot proceed with tests.');
        console.log(createResponse);
        return;
    }
    
    createdItemId = createResponse.data.data.itemId;
    console.log(`✓ Created shareable item in Dept 1 with ID: ${createdItemId}`);
    
    // STEP 3: Mark some quantity of the item as shareable
    console.log('\n--- Step 3: Mark Item as Shareable in Department 1 ---');
    
    const shareResponse = await callAPI(`/inventory/${createdItemId}/share`, 'POST', { quantity: 2 }, dept1.token);
    
    if (!shareResponse.success || !shareResponse.data.success) {
        console.log('Failed to mark item as shareable. Cannot proceed with further sharing tests.');
        console.log(shareResponse);
        return;
    }
    
    const sharedItem = shareResponse.data.data;
    console.log(`✓ Item "${sharedItem.itemName}" marked as shareable: ${sharedItem.sharedItems} of ${sharedItem.totalItems} items shared`);
    
    // STEP 4: Verify item appears in department 1's inventory
    console.log('\n--- Step 4: Verify Department 1 Inventory ---');
    
    const list1Response = await callAPI('/inventory', 'GET', null, dept1.token);
    
    if (!list1Response.success || !list1Response.data.success) {
        console.log('Failed to list department 1 inventory.');
        console.log(list1Response);
        return;
    }
    
    const foundItem = list1Response.data.data.find(item => item.itemId === createdItemId);
    
    if (foundItem) {
        console.log(`✓ Item correctly appears in department 1 inventory:`);
        console.log(` - Name: ${foundItem.itemName}`);
        console.log(` - Total: ${foundItem.totalItems}`);
        console.log(` - Available: ${foundItem.availableItems}`);
        console.log(` - Shared: ${foundItem.sharedItems}`);
        console.log(` - Sharable: ${foundItem.isSharable ? 'Yes' : 'No'}`);
    } else {
        console.log('❌ Item not found in department 1 inventory!');
    }
    
    // STEP 5: Check Department 2 can see sharable resources
    console.log('\n--- Step 5: Department 2 Checks Sharable Resources ---');
    
    const sharable2Response = await callAPI('/inventory/sharing', 'GET', null, dept2.token);
    
    if (!sharable2Response.success || !sharable2Response.data.success) {
        console.log('Department 2 failed to list sharable resources.');
        console.log(sharable2Response);
        return;
    }
    
    const foundSharableItem = sharable2Response.data.data.find(item => item.itemId === createdItemId);
    
    if (foundSharableItem) {
        console.log(`✓ Department 2 can see the sharable item from Department 1:`);
        console.log(` - Name: ${foundSharableItem.itemName}`);
        console.log(` - From Department: ${foundSharableItem.department.deptName}`);
        console.log(` - Shared quantity: ${foundSharableItem.sharedItems}`);
    } else {
        console.log('❌ Department 2 cannot see the sharable item from Department 1!');
    }
    
    // STEP 6: Department 2 requests the item
    console.log('\n--- Step 6: Department 2 Requests the Item ---');
    
    const requestBody = {
        itemId: createdItemId,
        fromDept: dept1.deptId,
        quantity: 1
    };
    
    const requestResponse = await callAPI('/inventory/request', 'POST', requestBody, dept2.token);
    
    if (!requestResponse.success || !requestResponse.data.success) {
        console.log('Department 2 failed to request the item.');
        console.log(requestResponse);
        return;
    }
    
    requestId = requestResponse.data.data.requestId;
    console.log(`✓ Department 2 successfully requested the item. Request ID: ${requestId}`);
    
    // STEP 7: Department 1 checks and approves the request
    console.log('\n--- Step 7: Department 1 Approves the Request ---');
    
    // First, check if request is visible
    const requests1Response = await callAPI('/inventory/requests', 'GET', null, dept1.token);
    
    if (!requests1Response.success || !requests1Response.data.success) {
        console.log('Department 1 failed to list requests.');
        console.log(requests1Response);
        return;
    }
    
    const foundRequest = requests1Response.data.data.find(req => req.requestId === requestId);
    
    if (foundRequest) {
        console.log(`✓ Department 1 can see the request from Department 2:`);
        console.log(` - Request ID: ${foundRequest.requestId}`);
        console.log(` - Status: ${foundRequest.requestStatus}`);
        console.log(` - From: ${foundRequest.fromDepartment?.deptName}`);
        console.log(` - For: ${foundRequest.forDepartment?.deptName}`);
        console.log(` - Quantity: ${foundRequest.quantity}`);
        
        // Now approve the request
        const approveResponse = await callAPI(
            `/inventory/request/${requestId}/status`, 
            'PUT', 
            { status: 'approved' }, 
            dept1.token
        );
        
        if (!approveResponse.success || !approveResponse.data.success) {
            console.log('Department 1 failed to approve the request.');
            console.log(approveResponse);
            return;
        }
        
        console.log(`✓ Department 1 approved the request.`);
    } else {
        console.log('❌ Department 1 cannot see the request from Department 2!');
        return;
    }
    
    // STEP 8: Department 2 checks their inventory for the borrowed item
    console.log('\n--- Step 8: Department 2 Checks Their Borrowed Items ---');
    
    const borrowed2Response = await callAPI('/inventory/borrowed', 'GET', null, dept2.token);
    
    if (!borrowed2Response.success || !borrowed2Response.data.success) {
        console.log('Department 2 failed to list borrowed items.');
        console.log(borrowed2Response);
        return;
    }
    
    let borrowedItemId = null;
    const foundBorrowedItem = borrowed2Response.data.data.find(item => 
        item.itemName === itemToCreate.itemName && 
        item.borrowedFromDeptId === dept1.deptId
    );
    
    if (foundBorrowedItem) {
        borrowedItemId = foundBorrowedItem.itemId;
        console.log(`✓ Department 2 received the borrowed item:`);
        console.log(` - Item ID: ${foundBorrowedItem.itemId}`);
        console.log(` - Name: ${foundBorrowedItem.itemName}`);
        console.log(` - Borrowed From: ${foundBorrowedItem.borrowedFromDepartment?.deptName}`);
        console.log(` - Quantity: ${foundBorrowedItem.borrowedQuantity}`);
    } else {
        console.log('❌ Department 2 cannot see the borrowed item in their inventory!');
        
        // Check regular inventory just in case
        const list2Response = await callAPI('/inventory', 'GET', null, dept2.token);
        if (list2Response.success && list2Response.data.success) {
            const allItems = list2Response.data.data;
            const possibleItem = allItems.find(item => 
                item.itemName === itemToCreate.itemName && 
                item.isBorrowed === true
            );
            
            if (possibleItem) {
                borrowedItemId = possibleItem.itemId;
                console.log(`! Found the item in regular inventory instead:`);
                console.log(` - Item ID: ${possibleItem.itemId}`);
                console.log(` - Name: ${possibleItem.itemName}`);
                console.log(` - Borrowed: ${possibleItem.isBorrowed ? 'Yes' : 'No'}`);
                console.log(` - Borrowed From: ${possibleItem.borrowedFromDeptId}`);
            } else {
                console.log('❌ Item not found in regular inventory either!');
                return;
            }
        }
    }
    
    // STEP 9: Department 1 checks their lent items
    console.log('\n--- Step 9: Department 1 Checks Their Lent Items ---');
    
    const lent1Response = await callAPI('/inventory/lent', 'GET', null, dept1.token);
    
    if (!lent1Response.success || !lent1Response.data.success) {
        console.log('Department 1 failed to list lent items.');
        console.log(lent1Response);
        return;
    }
    
    const foundLentItem = lent1Response.data.data.find(item => 
        item.borrowedFromDeptId === dept1.deptId && 
        item.deptId === dept2.deptId
    );
    
    if (foundLentItem) {
        console.log(`✓ Department 1 can see the lent item:`);
        console.log(` - Item ID: ${foundLentItem.itemId}`);
        console.log(` - Name: ${foundLentItem.itemName}`);
        console.log(` - Lent To: ${foundLentItem.department?.deptName}`);
    } else {
        console.log('❌ Department 1 cannot see the lent item!');
    }
    
    // STEP 10: Department 2 returns the item
    if (borrowedItemId) {
        console.log('\n--- Step 10: Department 2 Returns the Item ---');
        
        const returnBody = {
            itemId: borrowedItemId,
            toDept: dept1.deptId,
            quantity: 1
        };
        
        const returnResponse = await callAPI('/inventory/return', 'POST', returnBody, dept2.token);
        
        if (!returnResponse.success || !returnResponse.data.success) {
            console.log('Department 2 failed to return the item.');
            console.log(returnResponse);
            return;
        }
        
        console.log(`✓ Department 2 successfully returned the item to Department 1.`);
        
        // Check if item is removed from borrowed items
        const borrowedAfterResponse = await callAPI('/inventory/borrowed', 'GET', null, dept2.token);
        
        if (borrowedAfterResponse.success && borrowedAfterResponse.data.success) {
            const stillBorrowed = borrowedAfterResponse.data.data.find(item => item.itemId === borrowedItemId);
            
            if (stillBorrowed && stillBorrowed.borrowedQuantity > 0) {
                console.log('Note: Item is still in borrowed items but with reduced quantity.');
            } else {
                console.log(`✓ Item removed from borrowed items list.`);
            }
        }
        
        // Check if Department 1 received the item back
        const listAfterResponse = await callAPI('/inventory', 'GET', null, dept1.token);
        
        if (listAfterResponse.success && listAfterResponse.data.success) {
            const updatedItem = listAfterResponse.data.data.find(item => item.itemId === createdItemId);
            
            if (updatedItem) {
                console.log(`✓ Department 1 inventory updated:`);
                console.log(` - Available: ${updatedItem.availableItems}`);
                console.log(` - Shared: ${updatedItem.sharedItems}`);
            }
        }
    } else {
        console.log('\nSkipping return step as we couldn\'t identify the borrowed item ID.');
    }
    
    console.log('\n=== TEST SUMMARY ===');
    console.log(`✓ Successfully tested the complete cross-department flow:`);
    console.log('1. Department 1 created and shared an inventory item');
    console.log('2. Department 2 found the sharable item and requested it');
    console.log('3. Department 1 approved the request');
    console.log('4. Department 2 received the item and could see it in their borrowed items');
    console.log('5. Department 1 could see the item in their lent items list');
    console.log('6. Department 2 returned the item');
    console.log('7. Department 1 received the returned item');
}

// Run the tests
console.log('Starting cross-department functionality tests...');
runTests().catch(error => {
    console.error('Test failed with error:', error);
}); 