// Comprehensive testing script for the inventory management system
import fetch from 'node-fetch';
import colors from 'colors/safe.js';

// Configuration
const BASE_URL = 'http://localhost:3000/api';
const AUTH = {
    email: 'piyush.miraaz@gmail.com',
    password: 'piyush.miraaz'
};

// Store data for use across tests
let token = '';
let createdItemIds = [];
let requestId = '';
let departments = [];

// Helper function for API calls
async function callAPI(endpoint, method = 'GET', body = null, requiresAuth = true) {
    const headers = {
        'Content-Type': 'application/json'
    };
    
    if (requiresAuth && token) {
        headers['Authorization'] = `Bearer ${token}`;
    }
    
    const options = {
        method,
        headers
    };
    
    if (body && (method === 'POST' || method === 'PUT')) {
        options.body = JSON.stringify(body);
    }
    
    try {
        const response = await fetch(`${BASE_URL}${endpoint}`, options);
        const data = await response.json();
        return { status: response.status, data, success: true };
    } catch (error) {
        console.error(`${colors.red('Error')} calling ${endpoint}:`, error);
        return { status: 500, error: error.message, success: false };
    }
}

// Test reporter
function reportTest(name, result, details = null) {
    if (result) {
        console.log(`${colors.green('✓')} ${name}`);
    } else {
        console.log(`${colors.red('✗')} ${name}`);
        if (details) {
            console.log(`  ${colors.gray('Details:')} ${JSON.stringify(details, null, 2)}`);
        }
    }
}

// Main testing function
async function runTests() {
    console.log(colors.cyan('\n=== INVENTORY MANAGEMENT SYSTEM API TESTING ===\n'));
    
    // ===== Authentication =====
    console.log(colors.yellow('\n--- Authentication ---'));
    
    // Test 1: Login
    console.log('\nTesting Login API:');
    const loginResponse = await callAPI('/auth/login', 'POST', AUTH, false);
    reportTest('Login successful', 
        loginResponse.success && 
        loginResponse.status === 200 && 
        loginResponse.data.success && 
        loginResponse.data.data.accessToken, 
        loginResponse.success ? null : loginResponse
    );
    
    if (!loginResponse.success || !loginResponse.data.data.accessToken) {
        console.log(colors.red('Authentication failed. Cannot proceed with tests.'));
        return;
    }
    
    token = loginResponse.data.data.accessToken;
    const userInfo = loginResponse.data.data.user;
    console.log(`Logged in as: ${userInfo.name} (${userInfo.id}), Department: ${userInfo.deptId}`);
    
    // Get available departments for testing cross-department functions
    const deptsResponse = await callAPI('/departments');
    if (deptsResponse.success && deptsResponse.data.success) {
        departments = deptsResponse.data.data.filter(dept => dept.deptId !== userInfo.deptId);
        console.log(`Found ${departments.length} other departments for testing:`);
        departments.forEach(dept => console.log(`- ${dept.deptName} (${dept.deptId})`));
    } else {
        console.log(colors.yellow('Warning: Could not fetch departments. Cross-department tests may be limited.'));
    }
    
    // ===== Resource Management =====
    console.log(colors.yellow('\n--- Resource Management ---'));
    
    // Test 2: Create Resources
    console.log('\nTesting Create Resource API:');
    
    // Create multiple items with different properties
    const itemsToCreate = [
        {
            itemName: 'Test Laptop',
            itemCategory: 'Electronics',
            itemDescription: 'Laptop for testing inventory API',
            totalItems: 10,
            isSharable: true
        },
        {
            itemName: 'Office Chair',
            itemCategory: 'Furniture',
            itemDescription: 'Ergonomic office chair',
            totalItems: 5,
            isSharable: false
        },
        {
            itemName: 'Projector',
            itemCategory: 'Electronics',
            itemDescription: 'HD Projector for meetings',
            totalItems: 2,
            isSharable: true
        }
    ];
    
    for (let i = 0; i < itemsToCreate.length; i++) {
        const item = itemsToCreate[i];
        const createResponse = await callAPI('/inventory', 'POST', item);
        
        reportTest(`Create Resource ${i+1}: ${item.itemName}`, 
            createResponse.success && 
            createResponse.status === 201 && 
            createResponse.data.success, 
            createResponse.success ? null : createResponse
        );
        
        if (createResponse.success && createResponse.data.success) {
            createdItemIds.push(createResponse.data.data.itemId);
            console.log(`  Created item with ID: ${createResponse.data.data.itemId}`);
        }
    }
    
    // Test 3: List Department Resources
    console.log('\nTesting List Department Resources API:');
    const listResponse = await callAPI('/inventory');
    reportTest('List Resources successful', 
        listResponse.success && 
        listResponse.status === 200 && 
        listResponse.data.success, 
        listResponse.success ? null : listResponse
    );
    
    if (listResponse.success && listResponse.data.success) {
        console.log(`  Found ${listResponse.data.data.length} resources in department`);
        
        // If we couldn't create items, use existing ones for further tests
        if (createdItemIds.length === 0 && listResponse.data.data.length > 0) {
            createdItemIds = listResponse.data.data.map(item => item.itemId).slice(0, 3);
            console.log(`  Using existing items for testing: ${createdItemIds.join(', ')}`);
        }
    }
    
    // Test 4: Get Inventory History
    console.log('\nTesting Get Inventory History API:');
    const historyResponse = await callAPI('/inventory/history');
    reportTest('Get History successful', 
        historyResponse.success && 
        historyResponse.status === 200 && 
        historyResponse.data.success, 
        historyResponse.success ? null : historyResponse
    );
    
    if (historyResponse.success && historyResponse.data.success) {
        console.log(`  Found ${historyResponse.data.data.length} history records`);
    }
    
    // ===== Sharing Management =====
    console.log(colors.yellow('\n--- Sharing Management ---'));
    
    // Test 5: Mark Item as Sharable
    if (createdItemIds.length > 0) {
        console.log('\nTesting Mark Item as Sharable API:');
        const shareQuantity = 3;
        const shareResponse = await callAPI(`/inventory/${createdItemIds[0]}/share`, 'POST', { quantity: shareQuantity });
        
        reportTest('Mark as Sharable successful', 
            shareResponse.success && 
            shareResponse.status === 200 && 
            shareResponse.data.success, 
            shareResponse.success ? null : shareResponse
        );
        
        if (shareResponse.success && shareResponse.data.success) {
            const item = shareResponse.data.data;
            console.log(`  Item "${item.itemName}" now has ${item.sharedItems} shared items and ${item.availableItems} available items`);
            
            // Verify the logic - shared + available should equal total
            const correctMath = (item.sharedItems + item.availableItems === item.totalItems);
            reportTest('Shared + Available = Total', correctMath, 
                correctMath ? null : { 
                    shared: item.sharedItems, 
                    available: item.availableItems, 
                    total: item.totalItems 
                }
            );
        }
    } else {
        console.log(colors.yellow('Warning: No items available to test sharing.'));
    }
    
    // Test 6: Get Sharable Resources (from other departments)
    console.log('\nTesting Get Sharable Resources API:');
    const sharableResponse = await callAPI('/inventory/sharing');
    reportTest('Get Sharable Resources successful', 
        sharableResponse.success && 
        sharableResponse.status === 200 && 
        sharableResponse.data.success, 
        sharableResponse.success ? null : sharableResponse
    );
    
    if (sharableResponse.success && sharableResponse.data.success) {
        console.log(`  Found ${sharableResponse.data.data.length} sharable resources from other departments`);
    }
    
    // ===== Request System =====
    console.log(colors.yellow('\n--- Request System ---'));
    
    // Test 7: Create Resource Request
    // For this test, we need an item from another department
    if (sharableResponse.data.data.length > 0) {
        console.log('\nTesting Create Resource Request API:');
        const itemToBorrow = sharableResponse.data.data[0];
        const requestBody = {
            itemId: itemToBorrow.itemId,
            fromDept: itemToBorrow.deptId,
            quantity: 1
        };
        
        const requestResponse = await callAPI('/inventory/request', 'POST', requestBody);
        reportTest('Create Request successful', 
            requestResponse.success && 
            requestResponse.status === 201 && 
            requestResponse.data.success, 
            requestResponse.success ? null : requestResponse
        );
        
        if (requestResponse.success && requestResponse.data.success) {
            requestId = requestResponse.data.data.requestId;
            console.log(`  Created request with ID: ${requestId}`);
        }
    } else {
        console.log(colors.yellow('Warning: No sharable resources found from other departments to request.'));
    }
    
    // Test 8: Get Resource Requests
    console.log('\nTesting Get Resource Requests API:');
    const requestsResponse = await callAPI('/inventory/requests');
    reportTest('Get Requests successful', 
        requestsResponse.success && 
        requestsResponse.status === 200 && 
        requestsResponse.data.success, 
        requestsResponse.success ? null : requestsResponse
    );
    
    if (requestsResponse.success && requestsResponse.data.success) {
        console.log(`  Found ${requestsResponse.data.data.length} requests`);
        
        // If we didn't create a request but there are existing ones, use the first one
        if (!requestId && requestsResponse.data.data.length > 0) {
            requestId = requestsResponse.data.data[0].requestId;
            console.log(`  Using existing request for testing: ${requestId}`);
        }
    }
    
    // Test 9: Update Request Status (can't fully test without proper permissions)
    console.log('\nTesting Update Request Status API:');
    if (requestId) {
        // Note: This may fail if the user doesn't have permission to approve this request
        // (i.e., if they're not in the source department)
        const updateResponse = await callAPI(`/inventory/request/${requestId}/status`, 'PUT', { status: 'approved' });
        
        // This test might legitimately fail if the user doesn't have permission to update the request
        // (which is likely since requests are across departments)
        reportTest('Update Request Status', 
            updateResponse.success && 
            updateResponse.status === 200 && 
            updateResponse.data.success,
            updateResponse.success ? null : updateResponse
        );
        
        if (updateResponse.success && updateResponse.data.success) {
            console.log(`  Updated request status to: ${updateResponse.data.data.requestStatus}`);
        } else {
            console.log(colors.yellow('  Note: This test may fail if you don\'t have permission to approve the request.'));
        }
    } else {
        console.log(colors.yellow('Warning: No request found to test status update.'));
    }
    
    // ===== Borrowed and Lent Items =====
    console.log(colors.yellow('\n--- Borrowed and Lent Items ---'));
    
    // Test 10: Get Borrowed Items
    console.log('\nTesting Get Borrowed Items API:');
    const borrowedResponse = await callAPI('/inventory/borrowed');
    reportTest('Get Borrowed Items successful', 
        borrowedResponse.success && 
        borrowedResponse.status === 200 && 
        borrowedResponse.data.success, 
        borrowedResponse.success ? null : borrowedResponse
    );
    
    if (borrowedResponse.success && borrowedResponse.data.success) {
        console.log(`  Found ${borrowedResponse.data.data.length} borrowed items`);
    }
    
    // Test 11: Get Lent Items
    console.log('\nTesting Get Lent Items API:');
    const lentResponse = await callAPI('/inventory/lent');
    reportTest('Get Lent Items successful', 
        lentResponse.success && 
        lentResponse.status === 200 && 
        lentResponse.data.success, 
        lentResponse.success ? null : lentResponse
    );
    
    if (lentResponse.success && lentResponse.data.success) {
        console.log(`  Found ${lentResponse.data.data.length} lent items`);
    }
    
    // ===== Return/Transfer System =====
    console.log(colors.yellow('\n--- Return/Transfer System ---'));
    
    // Test 12: Return Borrowed Items
    console.log('\nTesting Return Borrowed Items API:');
    if (borrowedResponse.success && borrowedResponse.data.data.length > 0) {
        const itemToReturn = borrowedResponse.data.data[0];
        const returnBody = {
            itemId: itemToReturn.itemId,
            toDept: itemToReturn.borrowedFromDeptId,
            quantity: 1
        };
        
        const returnResponse = await callAPI('/inventory/return', 'POST', returnBody);
        reportTest('Return Borrowed Items successful', 
            returnResponse.success && 
            returnResponse.status === 200 && 
            returnResponse.data.success, 
            returnResponse.success ? null : returnResponse
        );
        
        if (returnResponse.success && returnResponse.data.success) {
            console.log(`  Successfully returned ${returnBody.quantity} units of item ${returnBody.itemId}`);
        }
    } else {
        console.log(colors.yellow('Warning: No borrowed items found to test return functionality.'));
    }
    
    // ===== Search & Filtering =====
    console.log(colors.yellow('\n--- Search & Filtering ---'));
    
    // Test 13: Search Inventory
    console.log('\nTesting Search Inventory API:');
    // Try various search queries
    const searchQueries = [
        { query: 'laptop', category: null, isSharable: null, isBorrowed: null },
        { query: null, category: 'Electronics', isSharable: null, isBorrowed: null },
        { query: null, category: null, isSharable: 'true', isBorrowed: null }
    ];
    
    for (let i = 0; i < searchQueries.length; i++) {
        const q = searchQueries[i];
        let queryString = '/inventory/search?';
        if (q.query) queryString += `query=${q.query}&`;
        if (q.category) queryString += `category=${q.category}&`;
        if (q.isSharable !== null) queryString += `isSharable=${q.isSharable}&`;
        if (q.isBorrowed !== null) queryString += `isBorrowed=${q.isBorrowed}&`;
        
        const searchResponse = await callAPI(queryString.slice(0, -1)); // Remove trailing & or ?
        
        let searchDesc = 'Search by ';
        if (q.query) searchDesc += `query "${q.query}"`;
        else if (q.category) searchDesc += `category "${q.category}"`;
        else if (q.isSharable) searchDesc += `sharable items`;
        else if (q.isBorrowed) searchDesc += `borrowed items`;
        
        reportTest(`${searchDesc}`, 
            searchResponse.success && 
            searchResponse.status === 200 && 
            searchResponse.data.success, 
            searchResponse.success ? null : searchResponse
        );
        
        if (searchResponse.success && searchResponse.data.success) {
            console.log(`  Found ${searchResponse.data.data.length} matching items`);
        }
    }
    
    console.log(colors.cyan('\n=== TEST SUMMARY ==='));
    console.log('All inventory management API endpoints have been tested.');
    console.log('Look at the test results above to identify any issues that need to be addressed.');
}

// Run the tests
console.log('Starting comprehensive API tests for inventory management system...');
runTests().catch(error => {
    console.error(colors.red('Test failed with error:'), error);
}); 