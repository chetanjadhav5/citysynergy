// Script to add borrowing fields to the common_inventory table
const { initializeDatabase } = require('./config/database');

async function addBorrowingFields() {
    try {
        console.log('Initializing database connection...');
        const sequelize = await initializeDatabase();
        
        console.log('\nAdding borrowing fields to common_inventory table:');
        
        // Check which fields are missing
        const [fields] = await sequelize.query('DESCRIBE common_inventory');
        const existingFields = fields.map(f => f.Field);
        
        // Add the fields that are missing
        const fieldsToAdd = [];
        if (!existingFields.includes('isBorrowed')) {
            fieldsToAdd.push("ADD COLUMN `isBorrowed` BOOLEAN NOT NULL DEFAULT FALSE");
        }
        
        if (!existingFields.includes('borrowedFromDeptId')) {
            fieldsToAdd.push(`
                ADD COLUMN \`borrowedFromDeptId\` VARCHAR(255) NULL,
                ADD CONSTRAINT \`fk_borrowed_from_dept\` 
                FOREIGN KEY (\`borrowedFromDeptId\`) 
                REFERENCES \`common_dept\` (\`deptId\`) 
                ON DELETE SET NULL
                ON UPDATE CASCADE
            `);
        }
        
        if (!existingFields.includes('borrowedQuantity')) {
            fieldsToAdd.push("ADD COLUMN `borrowedQuantity` INT NOT NULL DEFAULT 0");
        }
        
        if (!existingFields.includes('sharedItems')) {
            fieldsToAdd.push("ADD COLUMN `sharedItems` INT NOT NULL DEFAULT 0");
        }
        
        if (fieldsToAdd.length > 0) {
            const alterQuery = `ALTER TABLE common_inventory ${fieldsToAdd.join(', ')}`;
            console.log('Executing SQL:');
            console.log(alterQuery);
            
            await sequelize.query(alterQuery);
            console.log('✅ Successfully added borrowing fields to the table');
        } else {
            console.log('✅ All fields already exist in the table');
        }
        
        // Verify the fields were added
        const [updatedFields] = await sequelize.query('DESCRIBE common_inventory');
        console.log('\nUpdated Table Structure:');
        updatedFields.forEach(field => {
            console.log(`${field.Field}: ${field.Type} ${field.Null === 'YES' ? 'NULL' : 'NOT NULL'} ${field.Default ? `DEFAULT ${field.Default}` : ''}`);
        });
        
        process.exit(0);
    } catch (error) {
        console.error('Error:', error);
        process.exit(1);
    }
}

addBorrowingFields(); 